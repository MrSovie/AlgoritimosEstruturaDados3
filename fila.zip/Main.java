public class Main
{
	public static void main(String[] args) {
		Tpessoa p1 = new Tpessoa(20, 'F', "Maria");
		Tpessoa p2 = new Tpessoa(18, 'M', "jorge");
		
	Fila f = new Fila(100);
	
    f.enfileira(p1);
    f.enfileira(p1);
    f.enfileira(p2);
	
	f.imprime();
	}
}
