public class Fila
{
	int capacidade;
	int fim;
	int inicio;
    Tpessoa[] pessoa;
	
	
	public Fila(int t){
	    capacidade= t;
	    inicio= -1;
	    fim = -1;
	    pessoa = new Tpessoa[capacidade];
	    
	}
	
	public boolean vazia(){
	    return(inicio==fim);
	}
	
	public boolean cheia(){
	    if(capacidade==fim+1){
	        return true;
	    }
	        return false;
	}
	
	public void enfileira(Tpessoa p){
	   if(!cheia()){
	       if (inicio==-1){
	           inicio=0;
	       }
	       fim++;
	       pessoa[fim]=p;
	       capacidade++;
	   }
	}
	
	public void desenfileira(){
	    if(!vazia()){
	        inicio++;
	        capacidade--;
	    }
	    
	}
	
	public void imprime () {
          for (int i=inicio+1; i<=fim; i++){
              System.out.println (pessoa[i].nome);
              System.out.println (pessoa[i].idade);
          }
      }
}
