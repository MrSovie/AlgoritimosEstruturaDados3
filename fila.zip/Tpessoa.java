public class Tpessoa{
    
    int idade;
    char sexo;
    String nome;
    
    
    public Tpessoa(int i, char s, String n){
        idade= i;
        sexo=s;
        nome=n;
    }
    
}