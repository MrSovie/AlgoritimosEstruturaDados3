public class TADPilha
{

  int topo;
  int capacidade;
  int[] dados;


  public TADPilha (int tamanho){
    capacidade = tamanho;
    topo = -1;
    dados = new int[capacidade];
  }

  public void imprime (){
    for (int i = 0; i <= topo; i++){
        System.out.println (dados[i]);
    }
  }
 
 public void imprimecontrario (){
    for (int i = topo; i >= 0; i--){
        System.out.println (dados[i]);
    }
  }
   

  public void empilha (int valor){
    if (!cheia()){
        topo++;
        dados[topo] = valor;
    }else{
      System.out.println("ta cheio");
    }
  }

  public int desempilha (){
    if(!vazia()){
        topo = topo--;
        return dados[topo + 1];
    }else{
      System.out.println("ta vazia");
      return 0;
    }
  }

  public boolean cheia (){
    return (topo == capacidade - 1);
  }

  public boolean vazia (){
    return (topo == -1);
  }
    
}