public class Main
{
 
    
    
	public static void main(String[] args) {
		TADPilha p = new TADPilha(10);
		
	/*	p.empilha (10);
		p.empilha (30);
		
		System.out.println("pilha ao contrario");
		p.imprimecontrario();
		System.out.println("");
		System.out.println("pilha");
        p.imprime();
	*/
	int n=6;
	
	while(n%2==0)
	}
}

